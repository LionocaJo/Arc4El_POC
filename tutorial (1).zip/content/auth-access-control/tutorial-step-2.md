---
title: "Let's create a complete solution!"
slug: 'create-solution'
weight: 2
draft: false
---

## The demo project in a nutshell

In this tutorial, we will walk through the process of setting up a demonstration project that simulates pizza ordering at various ELIA sites.

Let's imagine a fictional scenario where ELIA's different site restaurants offer pizza ordering during lunchtime. 

![We love pizzas!](/auth-access-control/images/step-2-image-000.jpg)

From a high-level functional perspective, the project aims to allow restaurant managers to establish the pizza menu while enabling both internal and external employees to place orders.

Following a microservices architecture, the demonstration project will consist of two microservices:

1. **Pizza Catalog Microservice**: This microservice will be responsible for managing the pizza catalog specific to each site.

2. **Order Management Microservice**: Dedicated to handling the introduction and management of orders placed by employees.

Additionally, we will develop a frontend application accessible to both managers and employees.

So, let's get started and create an efficient and flexible pizza ordering system for ELIA's restaurants!

## Creation of a new blank solution

You have to create a new solution on your local repository `C:\PRJ`:

![Create a new blank solution](/auth-access-control/images/step-2-image-001.png)

In a learning context, you should never mention a name that could refer to a professional application, as this exercise involves registering your application.

_**A good practice is to prefix your project name with "Demo", followed by your Windows account ID and the suffix of your choice.**_

![Provide the name of the solution](/auth-access-control/images/step-2-image-002.png)

## Initialization of the application

It's time to initiate the implementation of the application thanks to the _Guidance_ extension!

You just have to open the _Solution Explorer View_ and to activate the action `Create Arc4u AspNetCore Solution => 2022.2.1` using the contextual menu:

![Generate the solution using Guidance](/auth-access-control/images/step-2-image-003.png)

A modal dialog will be displayed, asking you the company for which you are developing your application:

![Choose the company for the configuration of the solution](/auth-access-control/images/step-2-image-004.png)

The choice made using this modal dialog will adapt automatically the settings of the projects for the corresponding company.

_In the context of this tutorial, please select the configuration "Elia configuration"._

## Let the magic operate!

Once the configuration has been chosen, the _Guidance_ extension will immediately take over, creating the complete start-up infrastructure for your solution.

As a result, you should get this situation:

![Let's review the infrastructure created by Guidance](/auth-access-control/images/step-2-image-005.png)

## What elements have been generated?

The _Guidance_ extension has created this infrastructure of folder:

- A folder labeled `BE` (aka "Back-End") that will includes all the (future) projets related to the micro-services. It already includes the YARP service
- A folder labeled `FE` (aka "Front-End") that will gathers any front-end clients developed in the context of this application
- A folder labeled `OAuth2` that includes the requested OAuth2 settings for all the components of your solution (micro-service and FE clients)
- A folder labeled `Shared` that provides shared concepts for the whole solution

## About the YARP service

### Introduction

YARP means literally "_Yet Another Reverse Proxy_".  This acronym is the name of an open-source reverse proxy project launched by Microsoft a few years ago.

A standard proxy is software that acts as a gateway between a private network and the internet. It listens to outgoing HTTP requests and typically performs tasks related to privacy or security.

A reverse proxy operates in the opposite direction. It is usually installed within the local network, behind the firewall, and listens to incoming requests. It is commonly used as a router to redirect incoming requests to an appropriate endpoint, which can occur when multiple web servers run on a machine or to set up a load balancing system.

### The implementation realized by Guidance

The YARP service provided by the Guidance extension performs the following tasks:

- _Authenticating_ the user account of a request for using _Active Directory Federated Services (ADFS)_ through the _OpenID protocol_.
- _Authorizing_ the user account of a request for a request by utilizing ADFS and the information about the application, the roles and the corresponding operations managed by the system _Authorization Viewer_, employing the OAuth2.0 protocol that returns a token.
- _Redirecting_ the original request to the asked endpoint for the target microservice, including the token
- Exposing a facade that offers basic services to obtain information about the current environment.

This situation can be schematized as:

![Schematic overview](/auth-access-control/images/step-2-image-006.png)

(_Of course, this schema is definitively NOT a blue print_)

### About the structure of the YARP service

The YARP service is structured into several projects following the principles of _Domain-Driven Design (DDD) architecture_:

- **Domain**: This project encapsulates the core domain logic and entities of the YARP service. It defines the fundamental concepts, behaviors, and rules that govern the business domain.
- **Business Contract** (aka "Business Interface"): The business contract project serves as an interface layer that defines the contracts exposed by the YARP service. It allows for loose coupling between different components and provides a clear separation between the domain and external systems.
- **Business Layer**: The business layer project contains the application logic and orchestrates the interactions between the domain and external systems. It coordinates the execution of use cases, applies business rules, and enforces domain constraints.
- **Facade**: The facade project acts as an entry point for external systems or clients to interact with the YARP service. It provides a simplified and unified interface that abstracts the complexity of the underlying system.
- **Host**: The host project serves as the infrastructure layer for the YARP service. It handles the application startup, dependency injection, configuration, and hosting of the various components within the service.

Please be aware that the YARP service consists of two additional projects:

- **Client Facade SDK**: This project facilitates the code generation of the client facade using NSwag. It simplifies the utilization of the information endpoints exposed by the YARP service, providing an easier way to interact with the service.
- **Unit Test**: This project serves as the foundation for unit tests conducted against the business layer. It allows for testing the functionality and behavior of the business logic, ensuring its correctness and adherence to the specified requirements.
