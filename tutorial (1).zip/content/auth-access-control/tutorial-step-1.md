---
title: "Building a Microservice Architecture Application at ELIA"
slug: 'setup-environment'
weight: 1
draft: false
---

The purpose of this tutorial is to demonstrate how to create an application following the microservice architecture principles and patterns used at ELIA.

While this tutorial may resemble a _cooking recipe_, its primary objective is to illustrate the crucial steps and procedures involved in building such an application.

The tutorial consists of the following steps:

1. Ensuring the necessary prerequisites are available.
2. Initializing the infrastructure for a solution that hosts microservices.
3. Preparing each microservice.
4. Adding a persistence layer.
5. Implementing proper authentication mechanisms.
6. Enabling authorization based on application roles.
7. Defining a frontend client to consume and interact with the microservice's data.
8. Registering the resulting application to enable user authentication and authorization for testing purposes.

Throughout these steps, technical concepts encountered will be clarified and explained.

By following this tutorial, you will gain a practical understanding of building microservice applications using the patterns and practices employed at ELIA.

## Prerequisites

### Microsoft Visual Studio 2022

You must have the latest version of _Microsoft Visual Studio_, available through the _Software Center_ utility present on your virtual machine.

### Microsoft Visual Studio Extension _Guidance_

You can install the extension _Guidance_ by using your version of Microsoft Visual Studio without opening any project.

The management of extensions is accessible from the menu "_Extensions_":

![How to reach the menu "Extensions"?](/auth-access-control/images/step-1-image-001.png)

You can search for the "_Arc4u Guidance 2022_" extension in the extension catalog:

![Search for the Arc4u Guidance 2022 extension](/auth-access-control/images/step-1-image-002.png)

Once you have found the extension, then request for its download.  

**The most recent version is 2022.2.1.12.**

The extension will installed at the time you will close _Microsoft Visual Studio_:

![To accept the licence terms](/auth-access-control/images/step-1-image-003.png)

As previously mentioned, the _Guidance_ extension requires a paid license.  

**If you haven't already done so, please contact [Gilles Flisch](mailto:gilles.flisch@elia.be) to obtain a _license ID_.**

Once you've obtained a _license ID_, you'll need to register it in the Microsoft Visual Studio options.

![Open the options of Microsoft Visual Studio](/auth-access-control/images/step-1-image-004.png)

Locate the options dedicated to the Guidance extension to register your license ID:

![The encode the licence ID of Guidance](/auth-access-control/images/step-1-image-005.png)
