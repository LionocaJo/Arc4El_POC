---
title: "Let's implement the first microservice"
slug: 'create-microservice'
weight: 3
draft: false
---

We will start to implement the microservice "Pizzas" with the help of the _Guidance_ extension.

# The microservice "Pizzas" in a nutshell

The back-end microservice called 'Pizzas' will serve as the authoritative service providing information about all the pizzas available for ordering at each restaurant site.

In a first implementation, this service is responsible for fulfilling the following objectives:

- Retrieving the list of all available types of pizzas.
- Fetching detailed information about a specific pizza.
- Enabling the creation, modification, and deletion of a type of pizza.

# Creation of the microservice "Pizzas"

Once again, let's ask to _Guidance_ doing the job for us!

Start by opening the Solution Explorer View and selecting the "BE" folder. The contextual menu of Guidance will dynamically adapt and present the option to create a new microservice.

Then initiate the creation process by executing the command "_Add Arc4u Micro-Service => 2022.2.1_":

![Start a new microservice using Guidance](/auth-access-control/images/step-3-image-001.png)

A modal dialog form will appear, prompting you to enter a name for the microservice.

![Provide the service name](/auth-access-control/images/step-3-image-002.png)

Once you've provided the name, Guidance will immediately begin creating the structure of the microservice. 

This one consists of a set of projects:

![Let's review the infrastructure created by Guidance](/auth-access-control/images/step-3-image-003.png)

# Structure of the new microservice

Of course, the microservice created by the _Guidance_ extension also follows _Domain-Driven Design (DDD)_ principles and is organized into the following projects:

- **Domain**: Encapsulates the core domain logic and entities, defining fundamental concepts, behaviors, and rules.
- **Business Interface**: Defines contracts exposed by the service, enabling loose coupling and separation from external systems.
- **Business Layer:** Contains application logic, orchestrates domain and external system interactions, and enforces business rules and constraints.
- **Facade**: Serves as an entry point for external systems or clients, providing a simplified interface to abstract system complexity.
- **Host**: Handles infrastructure concerns such as application startup, dependency injection, configuration, and hosting.

Additionally, the microservice includes two extra projects:

- **Client Facade SDK**: Facilitates client facade code generation using NSwag, simplifying interaction with the service's information endpoints.
- **Unit Test**: Provides a foundation for testing the business layer's functionality and behavior, ensuring compliance with requirements.
