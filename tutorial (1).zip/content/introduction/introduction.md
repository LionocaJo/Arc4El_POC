---
title: "About the framework Arc4u"  
date: 2023-10-13       
slug: 'intro'
draft: false           
---

Creating a new application within the scope of the ELIA company is a complex operation due to various challenges: 

- Initializing a well-structured solution that consistently applies design pattern (_microservices, clean architecture_) according to the existing naming conventions.
- Applying the rules for secure identification throughout ADFS (Active Directory Federation Services).
- Implement the authorization process regarding to the established ELIA model. 

Realizing this process based solely on technical documentation and/or existing projects is a rather risky endeavor.  Moreover, the technical complexity of identification and authorization operations is not easy to grasp, even for experienced developers.

Fortunately, there are two tools at your disposal to help you carry out this operation without getting lost.

## Arc4u

_Arc4u_ is a free, open-source framework for the .NET ecosystem whose implementation was initiated over 20 years ago.  

### Why a framework?

When it comes to developing software applications in the .NET ecosystem, having a robust development framework can greatly enhance productivity, maintainability, and consistency. 

Usually, a development framework is a comprehensive set of tools, libraries, and guidelines that provide a structured approach to building applications. It offers a foundation on which developers can rely, streamlining the development process and enabling them to focus on the core functionality of their applications.

It handle "common" tasks (_such as configuration, caching, diagnostic, dependency injections, authentication and authorization..._), so developers don't have to reinvent the wheel for each project.

For developers working in a large company such ELIA, the _Arc4u_ framework offers several advantages that significantly contribute to the success of their projects:

### Standardization and Consistency

In large enterprise environments, numerous development teams may work on different projects simultaneously. 

The _Arc4u_ framework promotes standardization by establishing a common set of practices and coding conventions. This ensures that all applications adhere to the same architectural principles, making them easier to understand, maintain, and enhance.

### Accelerated Development

The reusable components and pre-built functionality provided by the _Arc4u_ framework accelerate the development process. 

Developers can leverage existing modules, libraries, and patterns, which reduces the time spent on repetitive tasks. This enables faster delivery of applications, crucial for enterprises with demanding project timelines.

### Scalability and Maintainability

The _Arc4u_ framework facilitates the creation of scalable architectures by incorporating proven design patterns and scalability principles. 

Furthermore, the _Arc4u_ framework sustains maintainability by enforcing best practices and modular architectures. This enables developers to easily understand and modify code written by others, fostering collaboration and reducing the learning curve when transitioning between projects.

### Security and Compliance

Security and compliance are of utmost importance. 

The _Arc4u_ framework provides mechanisms for implementing secure authentication, authorization, data validation, and encryption, ensuring that applications meet the necessary security standards.

### Support

The source code of the _Arc4u_ framework is available through the [GitHub platform](https://github.com/) at the following URL:

https://github.com/GFlisch/Arc4u

- You can benefit from support by sending your problem requests or your enhancement requests.  
- You are also cordially invited to submit your own proposals for improvement via pull requests.

## Guidance

_Guidance_ is a powerful extension for [Microsoft Visual Studio](https://visualstudio.microsoft.com/) that aims to streamline the development process of microservice-based applications by applying best practices and providing essential tools. 

Let's explore some of the key components and technologies integrated into _Guidance_.

### Yarp: A Versatile Reverse Proxy and API Gateway

_Guidance_ leverages [Yarp](https://microsoft.github.io/reverse-proxy/), a robust technology that serves as both a reverse proxy and an API gateway. 

With Yarp, developers can efficiently manage and route incoming requests to the appropriate microservices. It acts as a gateway, handling traffic distribution and load balancing, improving scalability and reliability.

### Secure Communication with OAuth2.0 and OpenID

To ensure secure communication, Guidance supports [OAuth2.0](https://oauth.net/2/) and [OpenID](https://openid.net/) protocols. These industry-standard security mechanisms safeguard REST and [gRPC](https://grpc.io/) services. 

By integrating OAuth2.0 and OpenID, developers can easily authenticate and authorize client requests, enforcing access control and protecting sensitive data.

### NSwag: Simplified API Documentation and Generation

_Guidance_ incorporates [NSwag](https://github.com/RicoSuter/NSwag), a powerful toolkit that simplifies API documentation and generation. 

NSwag enables developers to automatically generate client SDKs, server stubs, and API documentation from the application's codebase. This streamlines the development process and enhances collaboration between frontend and backend teams.

### Asynchronous Architecture with RabbitMQ and NServiceBus

_Guidance_ promotes an efficient and scalable asynchronous architecture by utilizing [RabbitMQ](https://www.rabbitmq.com/) and [NServiceBus](https://particular.net/nservicebus). 

RabbitMQ acts as a message broker, enabling reliable and asynchronous communication between microservices. NServiceBus provides additional capabilities, such as message routing, publish-subscribe patterns, and fault tolerance, further enhancing the reliability and robustness of the system.

### Job Scheduling with Hangfire

To simplify job scheduling and background processing, Guidance integrates [Hangfire](https://www.hangfire.io/). 

With Hangfire, developers can effortlessly manage recurring tasks, background jobs, and distributed workflows. It provides a user-friendly dashboard and comprehensive job management capabilities, ensuring reliable execution and monitoring of scheduled tasks.

### Built on the Arc4u Framework

_Guidance_ is built entirely on the [_Arc4u_ framework](https://github.com/GFlisch/Arc4u). 

As detailed previously, the _Arc4u_ framework provides a solid foundation for developing microservice-based applications. It offers a comprehensive set of reusable components, design patterns, and utilities that promote scalability, maintainability, and code consistency.

## Licencing model

Unlike the _Arc4u_ framework, the Visual Studio extension _Guidance_ is not free and requires a developer license.

Developers and software architects working at Elia can obtain such a license for their work.  

Please take contact with [Gilles Flisch](mailto:gilles.flisch@elia.be) to obtain your license.