---
linkTitle: 高级配置
title: 高级配置
prev: /docs/guide/shortcodes/tabs
next: /docs/advanced/multi-language
---

此部分提供了 Hextra 的一些高级配置。

<!--more-->

{{< cards >}}
  {{< card link="multi-language" title="多语言" icon="translate" >}}
  {{< card link="customization" title="定制化" icon="pencil" >}}
{{< /cards >}}
